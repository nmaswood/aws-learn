import os

SQS_QUEUE_URL = os.environ["SQS_QUEUE_URL"]
DEFAULT_AWS_REGION = os.environ["DEFAULT_AWS_REGION"]
