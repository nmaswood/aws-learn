import os

RDS_URL = os.environ["RDS_URL"]
RDS_PORT = os.environ["RDS_PORT"]
RDS_USERNAME = os.environ["RDS_USERNAME"]
RDS_PASSWORD = os.environ["RDS_PASSWORD"]
