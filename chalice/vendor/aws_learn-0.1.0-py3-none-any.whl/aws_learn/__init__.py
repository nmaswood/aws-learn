from aws_learn.chalice import app


def hello_world():
    return {"hello": "world"}
